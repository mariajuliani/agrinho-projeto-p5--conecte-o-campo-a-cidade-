let cityX = 550, cityY = 100;
let fieldX = 50, fieldY = 300;
let path = [];
let trees = [];

function setup() {
  createCanvas(600, 400);
  for (let i = 0; i < 8; i++) {
    trees.push(createVector(random(100, 500), random(100, 350)));
  }
}

function draw() {
  background(200, 240, 200);
  
  fill(80); rect(cityX, cityY, 40, 60); // cidade
  fill(100, 200, 100); rect(fieldX, fieldY, 40, 40); // campo

  // árvores
  fill(0, 150, 0);
  for (let t of trees) ellipse(t.x, t.y, 30, 30);

  // caminho desenhado
  stroke(0); noFill();
  beginShape();
  for (let p of path) vertex(p.x, p.y);
  endShape();

  fill(0); textSize(14);
  text("Conecte o campo à cidade sem tocar as árvores!", 10, 20);

  checkConnection();
}

function mouseDragged() {
  path.push(createVector(mouseX, mouseY));
}

function checkConnection() {
  if (dist(mouseX, mouseY, cityX, cityY) < 50) {
    noLoop();
    let hit = false;
    for (let p of path) {
      for (let t of trees) {
        if (dist(p.x, p.y, t.x, t.y) < 20) {
          hit = true;
        }
      }
    }
    background(hit ? 'red' : 'green');
    textSize(32);
    fill(255);
    text(hit ? "Você danificou a natureza!" : "Conexão Sustentável!", 100, height / 2);
  }
}